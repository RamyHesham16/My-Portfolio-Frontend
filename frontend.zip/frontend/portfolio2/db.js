const express = require('express');
const app = express();
const port = 3000 ;

app.use(express.json());

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/newDb1')
const studentSchema = new mongoose.Schema({
  name: String,
  age: Number,
  grade: Number,
  isActive : Boolean,
},{
  timestamps: true,
})
// create a new model
const Student = mongoose.model('Student', studentSchema);
app.post('/student',async (req,res)=>{
  const newStudent = new Student(req.body);
  try{
    const result = await newStudent.save();
    res.status(201).json(result);
  }catch(error){
    res.status(400).json({error: error.message});
  }
})
app.listen(port,()=>{
  console.log(`Server is running on port ${port}`);
});

