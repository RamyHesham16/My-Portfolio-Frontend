import { Component, inject } from '@angular/core';
import { AboutService, IAbout } from '../../components/about-me/about.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UploadService } from '../../upload.service';

@Component({
  selector: 'app-d-about',
  templateUrl: './d-about.component.html',
  styleUrl: './d-about.component.css',
})
export class DAboutComponent {
  aboutService = inject(AboutService);
  uploadService = inject(UploadService);
  aboutData!: IAbout;
  editForm!: FormGroup;
  currentEdit = 'None';

  ngOnInit() {
    this.editForm = new FormGroup({
      value: new FormControl('', Validators.required),
    });
    this.aboutService.getAboutData().subscribe((res) => {
      this.aboutData = res[0];
    });
  }

  edit(el: string) {
    switch (el) {
      case 'img':
        this.currentEdit = 'Image';
        break;
      case 'desc':
        this.editForm.patchValue({
          value: this.aboutData.description,
        });
        this.currentEdit = 'Description';
        break;
      default:
        break;
    }
  }

  saveAboutData(el: string) {
    if (this.currentEdit === 'Image') {
      const imgElement = document.getElementById('img') as HTMLInputElement;
      const img = imgElement.files![0];
      this.uploadService.uploadImage(img).subscribe((res) => {
        this.aboutData.img = res.filepath;
        this.uploadData();
      });
    } else {
      this.aboutData.description = this.editForm.value.value;
      this.uploadData();
    }
  }

  uploadData() {
    this.aboutService.updateAboutData(this.aboutData).subscribe((res) => {
      this.aboutService.getAboutData().subscribe((res) => {
        this.currentEdit = 'None';
        this.editForm.reset();
      });
    });
  }
}
