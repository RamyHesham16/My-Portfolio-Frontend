import { Component, inject } from '@angular/core';
import {
  CertificationsService,
  ICertificate,
} from '../../components/certifications/certifications.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UploadService } from '../../upload.service';

@Component({
  selector: 'app-d-certificates',
  templateUrl: './d-certificates.component.html',
  styleUrl: './d-certificates.component.css',
})
export class DCertificatesComponent {
  certificatesService = inject(CertificationsService);
  uploadService = inject(UploadService);
  certificateData!: ICertificate[];
  editMode = false;
  editForm!: FormGroup;
  newCertificate!: ICertificate;
  addForm!: FormGroup;

  ngOnInit() {
    this.editForm = new FormGroup({
      title: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
      image: new FormControl(''),
      link: new FormControl('', Validators.required),
    });
    this.addForm = new FormGroup({
      title: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
      image: new FormControl('', Validators.required),
      link: new FormControl('', Validators.required),
    });
    this.certificatesService.getCertifications().subscribe((res) => {
      this.certificateData = res;
    });
  }

  deleteCertificate(id: string | undefined) {
    this.certificatesService.deleteCertificate(id).subscribe((res) => {
      this.certificatesService.getCertifications().subscribe((res) => {
        this.certificateData = res;
      });
    });
  }

  toggleEditMode(cert: ICertificate) {
    if (!this.editMode) {
      this.editMode = true;
      this.editForm.patchValue({
        title: cert.title,
        description: cert.description,
        link: cert.link,
      });
    } else {
      this.editForm.patchValue({
        title: cert.title,
        description: cert.description,
        link: cert.link,
      });
    }
    this.newCertificate = cert;
  }

  cancelEditMode() {
    this.editMode = false;
    this.editForm.reset();
  }

  updateCertificate() {
    this.newCertificate.title = this.editForm.value.title;
    this.newCertificate.description = this.editForm.value.description;
    this.newCertificate.link = this.editForm.value.link;
    if (this.editForm.value.image) {
      const imgElement = document.getElementById('img') as HTMLInputElement;
      const img = imgElement.files![0];
      this.uploadService.uploadImage(img).subscribe((res) => {
        this.newCertificate.img = res.filepath;
        this.certificatesService
          .updateCertificate(this.newCertificate)
          .subscribe((res) => {
            this.certificatesService.getCertifications().subscribe((res) => {
              this.certificateData = res;
              this.newCertificate = {} as ICertificate;
              this.editForm.reset();
              this.editMode = false;
            });
          });
      });
    } else {
      this.certificatesService
        .updateCertificate(this.newCertificate)
        .subscribe((res) => {
          this.certificatesService.getCertifications().subscribe((res) => {
            this.certificateData = res;
            this.newCertificate = {} as ICertificate;
            this.editForm.reset();
            this.editMode = false;
          });
        });
    }
  }

  saveCertificate() {
    const imgElement = document.getElementById('img') as HTMLInputElement;
    const img = imgElement.files![0];
    this.uploadService.uploadImage(img).subscribe((res) => {
      this.newCertificate = {
        title: this.addForm.value.title,
        description: this.addForm.value.description,
        img: res.filepath,
        link: this.addForm.value.link,
      };
      this.certificatesService
        .addNewCertificate(this.newCertificate)
        .subscribe((res) => {
          this.certificatesService.getCertifications().subscribe((res) => {
            this.certificateData = res;
            this.newCertificate = {} as ICertificate;
            this.addForm.reset();
          });
        });
    });
  }
}
