import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DResumeComponent } from './d-resume.component';

describe('DResumeComponent', () => {
  let component: DResumeComponent;
  let fixture: ComponentFixture<DResumeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DResumeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DResumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
