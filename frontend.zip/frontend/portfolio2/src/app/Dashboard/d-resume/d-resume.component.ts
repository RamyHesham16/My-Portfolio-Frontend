import { Component, inject } from '@angular/core';
import { IResume, ResumeService } from '../../components/resume/resume.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UploadService } from '../../upload.service';

@Component({
  selector: 'app-d-resume',
  templateUrl: './d-resume.component.html',
  styleUrl: './d-resume.component.css',
})
export class DResumeComponent {
  resumeService = inject(ResumeService);
  uploadService = inject(UploadService);
  resumeData!: IResume;
  editForm!: FormGroup;
  currentEdit = '';

  ngOnInit() {
    this.editForm = new FormGroup({
      value: new FormControl('', Validators.required),
    });
    this.resumeService.getResumeData().subscribe((res) => {
      this.resumeData = res[0];
    });
  }

  edit(el: string) {
    switch (el) {
      case 'img':
        this.currentEdit = 'Image';
        break;
      case 'source':
        this.editForm.patchValue({
          value: this.resumeData.CVSourceUrl,
        });
        this.currentEdit = 'CV Source URL';
        break;
      default:
        break;
    }
  }

  saveResumeData(el: string) {
    if (this.currentEdit === 'Image') {
      const imgElement = document.getElementById('img') as HTMLInputElement;
      const img = imgElement.files![0];
      this.uploadService.uploadImage(img).subscribe((res) => {
        this.resumeData.img = res.filepath;
        this.uploadData();
      });
    } else {
      this.resumeData.CVSourceUrl = this.editForm.value.value;
      this.uploadData();
    }
  }

  uploadData() {
    this.resumeService.updateResumeData(this.resumeData).subscribe((res) => {
      this.resumeService.getResumeData().subscribe((res) => {
        this.currentEdit = 'None';
        this.editForm.reset();
      });
    });
  }
}
