import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DSkillsComponent } from './d-skills.component';

describe('DSkillsComponent', () => {
  let component: DSkillsComponent;
  let fixture: ComponentFixture<DSkillsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DSkillsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DSkillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
