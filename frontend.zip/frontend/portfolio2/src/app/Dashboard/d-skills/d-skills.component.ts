import { Component, inject } from '@angular/core';
import { ISkill, SkillsService } from '../../components/skills/skills.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UploadService } from '../../upload.service';

@Component({
  selector: 'app-d-skills',
  templateUrl: './d-skills.component.html',
  styleUrl: './d-skills.component.css',
})
export class DSkillsComponent {
  skillsService = inject(SkillsService);
  uploadService = inject(UploadService);
  skillsData!: ISkill[];
  editMode = false;
  editForm!: FormGroup;
  newSkill!: ISkill;
  addForm!: FormGroup;

  ngOnInit() {
    this.editForm = new FormGroup({
      name: new FormControl('', Validators.required),
      category: new FormControl('', Validators.required),
      image: new FormControl(''),
      link: new FormControl('', Validators.required),
    });
    this.addForm = new FormGroup({
      name: new FormControl('', Validators.required),
      category: new FormControl('', Validators.required),
      image: new FormControl('', Validators.required),
      link: new FormControl('', Validators.required),
    });
    this.skillsService.getSkills().subscribe((res) => {
      this.skillsData = res;
    });
  }

  deleteSkill(id: string | undefined) {
    this.skillsService.deleteSkill(id).subscribe((res) => {
      this.skillsService.getSkills().subscribe((res) => {
        this.skillsData = res;
      });
    });
  }

  toggleEditMode(skill: ISkill) {
    if (!this.editMode) {
      this.editMode = true;
      this.editForm.patchValue({
        name: skill.name,
        category: skill.category,
        link: skill.imgUrl,
      });
    } else {
      this.editForm.patchValue({
        name: skill.name,
        category: skill.category,
        link: skill.imgUrl,
      });
    }
    this.newSkill = skill;
  }

  cancelEditMode() {
    this.editMode = false;
    this.editForm.reset();
  }

  updateSkill() {
    this.newSkill.name = this.editForm.value.name;
    this.newSkill.category = this.editForm.value.category;
    this.newSkill.imgUrl = this.editForm.value.link;
    if (this.editForm.value.image) {
      const imgElement = document.getElementById('img') as HTMLInputElement;
      const img = imgElement.files![0];
      this.uploadService.uploadImage(img).subscribe((res) => {
        this.newSkill.img = res.filepath;
        this.skillsService.updateSkill(this.newSkill).subscribe((res) => {
          this.skillsService.getSkills().subscribe((res) => {
            this.skillsData = res;
            this.newSkill = {} as ISkill;
            this.editForm.reset();
            this.editMode = false;
          });
        });
      });
    } else {
      this.skillsService.updateSkill(this.newSkill).subscribe((res) => {
        this.skillsService.getSkills().subscribe((res) => {
          this.skillsData = res;
          this.newSkill = {} as ISkill;
          this.editForm.reset();
          this.editMode = false;
        });
      });
    }
  }

  saveSkill() {
    const imgElement = document.getElementById('img') as HTMLInputElement;
    const img = imgElement.files![0];
    this.uploadService.uploadImage(img).subscribe((res) => {
      this.newSkill = {
        name: this.addForm.value.name,
        category: this.addForm.value.category,
        img: res.filepath,
        imgUrl: this.addForm.value.link,
      };
      this.skillsService.addNewSkill(this.newSkill).subscribe((res) => {
        this.skillsService.getSkills().subscribe((res) => {
          this.skillsData = res;
          this.newSkill = {} as ISkill;
          this.addForm.reset();
        });
      });
    });
  }
}
