import { Component, inject } from '@angular/core';
import { HomeService, IHome } from '../../components/home/home.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  homeService = inject(HomeService);
  homeData!: IHome;
  links!: string[];
  editForm!: FormGroup;
  currentEdit = "None";

  ngOnInit(){
    this.editForm = new FormGroup({
      value: new FormControl('', Validators.required),
    });
    this.homeService.getHomeData().subscribe(res => {
      this.homeData = res[0];
      this.links = this.homeData.links;
    })
  }

  edit(el: string){
    switch(el){
      case "name":
        this.editForm.patchValue({
          value: this.homeData.name
        });
        this.currentEdit = 'Name';
        break;
        case "desc1":
          this.editForm.patchValue({
            value: this.homeData.description1
          });
          this.currentEdit = 'Description 1';
          break;
        case "desc2":
          this.editForm.patchValue({
            value: this.homeData.description2
          });
          this.currentEdit = 'Description 2';
          break;
        case "mail":
          this.editForm.patchValue({
            value: this.links[0]
          });
          this.currentEdit = 'Mail Link';
          break;
        case "github":
          this.editForm.patchValue({
            value: this.links[1]
          });
          this.currentEdit = 'Github Link';
          break;
        case "linkedin":
          this.editForm.patchValue({
            value: this.links[2]
          });
          this.currentEdit = 'LinkedIn Link';
          break;
        case "massenger":
          this.editForm.patchValue({
            value: this.links[2]
          });
          this.currentEdit = 'Massenger Link';
          break;
        default:
        break;
    }
  }

  saveHomeData(el: string){
    switch(el){
      case "Name":
        this.homeData.name = this.editForm.value.value;
        break;
      case "Description 1":
        this.homeData.description1 = this.editForm.value.value;
        break;
      case "Description 2":
        this.homeData.description2 = this.editForm.value.value;
        break;
      case "Mail Link":
        this.links[0] = this.editForm.value.value;
        break;
      case "Github Link":
        this.links[1] = this.editForm.value.value;
        break;
      case "LinkedIn Link":
        this.links[2] = this.editForm.value.value;
        break;
      case "Massenger Link":
        this.links[3] = this.editForm.value.value;
        break;
      default:
        break;
    }
    this.homeData.links = this.links as [string];
    this.homeService.updateHomeData(this.homeData).subscribe(res => {
      this.homeService.getHomeData().subscribe(res => {
        this.editForm.reset();
        this.currentEdit = "None";
      });
    })
  }
}
