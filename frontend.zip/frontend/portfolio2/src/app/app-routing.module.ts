import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutMeComponent } from './components/about-me/about-me.component';
import { ResumeComponent } from './components/resume/resume.component';
import { CertificationsComponent } from './components/certifications/certifications.component';

import { SkillsComponent } from './components/skills/skills.component';
import { DashboardComponent } from './Dashboard/dashboard/dashboard.component';
import { DashboardHeaderComponent } from './shared/dashboard-header/dashboard-header.component';
import { DAboutComponent } from './Dashboard/d-about/d-about.component';
import { DCertificatesComponent } from './Dashboard/d-certificates/d-certificates.component';
import { DSkillsComponent } from './Dashboard/d-skills/d-skills.component';
import { DResumeComponent } from './Dashboard/d-resume/d-resume.component';
// DResumeComponent

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutMeComponent },
  { path:'resume', component: ResumeComponent},
  { path:'certificates', component: CertificationsComponent},
  { path:'skills', component: SkillsComponent},
  { path:'', redirectTo: 'home', pathMatch: "full" },
  { path: 'dashboard-123', component: DashboardComponent },
  { path: 'dashboardHeader', component: DashboardHeaderComponent },
  { path: 'd-about', component: DAboutComponent },
  { path: 'd-certificates', component: DCertificatesComponent },
  { path: 'd-skills', component: DSkillsComponent },
  { path: 'd-resume', component: DResumeComponent },


]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
