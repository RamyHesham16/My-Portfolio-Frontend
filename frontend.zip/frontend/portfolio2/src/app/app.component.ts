import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'portfolio2';
  constructor(public router: Router) {}

  hideDashboardHeader(): boolean {
    return this.router.url === '/home' || this.router.url === '/about'|| this.router.url === '/resume'
    || this.router.url === '/certificates' || this.router.url === '/skills';  // Replace with your specific route
  }
}
