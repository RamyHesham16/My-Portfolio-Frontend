import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { AboutMeComponent } from './components/about-me/about-me.component';
import { ResumeComponent } from './components/resume/resume.component';
import { CertificationsComponent } from './components/certifications/certifications.component';

import { SkillsComponent } from './components/skills/skills.component';
import { DashboardComponent } from './Dashboard/dashboard/dashboard.component';
import { DashboardHeaderComponent } from './shared/dashboard-header/dashboard-header.component';
import { DAboutComponent } from './Dashboard/d-about/d-about.component';
import { DCertificatesComponent } from './Dashboard/d-certificates/d-certificates.component';
import { DResumeComponent } from './Dashboard/d-resume/d-resume.component';
import { DSkillsComponent } from './Dashboard/d-skills/d-skills.component';
import { provideHttpClient, withFetch } from '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AboutMeComponent,
    ResumeComponent,
    CertificationsComponent,

    SkillsComponent,
    DashboardComponent,
    DashboardHeaderComponent,
    DAboutComponent,
    DCertificatesComponent,
    DResumeComponent,
    DSkillsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
  ],
  providers: [
    provideClientHydration(),
    provideHttpClient(withFetch()),
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
