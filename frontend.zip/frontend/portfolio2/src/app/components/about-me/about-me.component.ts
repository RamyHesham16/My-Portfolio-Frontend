import { Component, inject } from '@angular/core';
import { AboutService, IAbout } from './about.service';

@Component({
  selector: 'app-about-me',
  templateUrl: './about-me.component.html',
  styleUrl: './about-me.component.css'
})
export class AboutMeComponent {
  aboutService = inject(AboutService);
  aboutData!: IAbout;

  ngOnInit() {
    this.aboutService.getAboutData().subscribe(res => {
      this.aboutData = res[0];
    })
  }

}
