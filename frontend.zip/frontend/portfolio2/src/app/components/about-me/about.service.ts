import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AboutService {
  http = inject(HttpClient);

  getAboutData(): Observable<any> {
    return this.http.get("http://localhost:3000/about");
  }

  updateAboutData(data: IAbout): Observable<any> {
    return this.http.patch('http://localhost:3000/about', data);
  }
}

export interface IAbout {
  _id?: string,
  description: string,
  img: string
}
