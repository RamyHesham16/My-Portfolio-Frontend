import { Component, inject } from '@angular/core';
import { CertificationsService, ICertificate } from './certifications.service';

@Component({
  selector: 'app-certifications',
  templateUrl: './certifications.component.html',
  styleUrl: './certifications.component.css'
})
export class CertificationsComponent {
  certService = inject(CertificationsService);
  certificates: ICertificate[] = [];

  ngOnInit(){
    this.certService.getCertifications().subscribe(res => {
      this.certificates = res;
    })
  }
}
