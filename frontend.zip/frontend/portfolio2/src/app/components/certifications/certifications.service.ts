import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CertificationsService {
  http = inject(HttpClient);

  getCertifications(): Observable<any> {
    return this.http.get('http://localhost:3000/certificates');
  }

  deleteCertificate(id: string | undefined): Observable<any> {
    return this.http.delete(`http://localhost:3000/certificates/${id}`);
  }

  updateCertificate(certificate: ICertificate): Observable<any> {
    return this.http.patch(
      `http://localhost:3000/certificates/${certificate._id}`,
      certificate
    );
  }

  addNewCertificate(certificate: ICertificate): Observable<any> {
    return this.http.post(`http://localhost:3000/certificates`, certificate);
  }
}

export interface ICertificate {
  _id?: string;
  img: string;
  title: string;
  description: string;
  link: string;
}
