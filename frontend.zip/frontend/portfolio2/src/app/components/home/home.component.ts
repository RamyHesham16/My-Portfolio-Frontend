import { Component, inject } from '@angular/core';
import { HomeService } from './home.service';
import { IHome } from './home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  service = inject(HomeService)
  homeData!: IHome;
  links: string[] = [];

  ngOnInit(){
    this.service.getHomeData().subscribe(res => {
      this.homeData = res[0];
      this.homeData.links.forEach(link => {
        this.links.push(link);
      });
    });
  }

}
