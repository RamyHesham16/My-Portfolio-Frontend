import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  http = inject(HttpClient);

  getHomeData(): Observable<any> {
    return this.http.get('http://localhost:3000/home');
  }

  updateHomeData(data: IHome): Observable<any> {
    return this.http.patch('http://localhost:3000/home', data);
  }
}


export interface IHome {
  _id?: string;
  name: String,
  description1: string,
  description2: string,
  links : [string],
}

