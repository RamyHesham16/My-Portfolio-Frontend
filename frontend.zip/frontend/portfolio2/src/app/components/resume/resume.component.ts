import { Component, inject } from '@angular/core';
import { IResume, ResumeService } from './resume.service';

@Component({
  selector: 'app-resume',
  templateUrl: './resume.component.html',
  styleUrl: './resume.component.css'
})
export class ResumeComponent {
  resumeService = inject(ResumeService);
  resumeData!: IResume;

  ngOnInit(){
    this.resumeService.getResumeData().subscribe(res => {
      this.resumeData = res[0];
    })
  }

}
