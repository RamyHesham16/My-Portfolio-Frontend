import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ResumeService {
  http = inject(HttpClient);

  getResumeData(): Observable<any> {
    return this.http.get('http://localhost:3000/resume');
  }

  updateResumeData(data: IResume): Observable<any> {
    return this.http.patch('http://localhost:3000/resume', data);
  }
}


export interface IResume {
  _id?: string;
  CVSourceUrl: string,
  img: string,
}
