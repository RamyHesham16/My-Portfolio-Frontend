import { Component, inject } from '@angular/core';
import { SkillsService } from './skills.service';
import { ISkill } from './skills.service'

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrl: './skills.component.css'
})
export class SkillsComponent {
  skillsService = inject(SkillsService);
  skills!: ISkill[];
  programmingLanguages: ISkill[] = [];
  web: ISkill[] = [];
  databases: ISkill[] = [];
  SoftwaresTools: ISkill[] = [];
  Services: ISkill[] = [];
  SoftSkills: ISkill[] = [];

  ngOnInit(){
    this.skillsService.getSkills().subscribe(res => {
      this.skills = res;
      for(let skill of this.skills) {
        switch(skill.category) {
          case 'programing languages':
            this.programmingLanguages.push(skill);
            break;
          case 'Web Programming and technologies ':
            this.web.push(skill);
            break;
          case 'Databases':
            this.databases.push(skill);
            break;
          case 'Softwares and tools':
            this.SoftwaresTools.push(skill);
            break;
          case 'Services':
            this.Services.push(skill);
            break;
          case 'Soft Skills':
            this.SoftSkills.push(skill);
            break;

        }
      }


    })
  }
}


