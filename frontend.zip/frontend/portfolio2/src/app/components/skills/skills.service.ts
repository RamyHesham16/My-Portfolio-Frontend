import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SkillsService {
  http = inject(HttpClient);

  getSkills(): Observable<any> {
    return this.http.get('http://localhost:3000/skills');
  }

  deleteSkill(id: string | undefined): Observable<any> {
    return this.http.delete(`http://localhost:3000/skills/${id}`);
  }

  updateSkill(skill: ISkill): Observable<any> {
    return this.http.patch(`http://localhost:3000/skills/${skill._id}`, skill);
  }

  addNewSkill(skill: ISkill): Observable<any> {
    return this.http.post(`http://localhost:3000/skills`, skill);
  }
}

export interface ISkill {
  _id?: string;
  name: string;
  category: string;
  img: string;
  imgUrl: string;
}
